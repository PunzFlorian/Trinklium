using Terraria.ModLoader;

namespace Trinklium
{
	class Trinklium : Mod
	{
		public Trinklium()
		{
			Properties = new ModProperties()
			{
				Autoload = true,
				AutoloadGores = true,
				AutoloadSounds = true
			};
		}
	}
}
